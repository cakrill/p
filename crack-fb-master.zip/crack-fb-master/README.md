# Hack Facebook
```
$ pkg update && pkg upgrade
$ pkg install python2 git
$ pip2 install requests mechanize
$ git clone https://github.com/ariyazz/crack-fb
$ cd crack-fb
$ python2 fb.py
```
